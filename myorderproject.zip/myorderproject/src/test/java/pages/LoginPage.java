package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import testcases.BaseTest;

public class LoginPage extends BaseTest {

	WebDriver driver;
	JavascriptExecutor js;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(xpath = "//a[@class='login']")
	WebElement signin;

	@FindBy(xpath = "//div/input[@type='text' and @id='email']")
	WebElement emailValue;

	@FindBy(xpath = "//*[@id='passwd']")
	WebElement passwordValue;

	@FindBy(xpath = "//*[@id='SubmitLogin']")
	WebElement submitLogin;

	public void login() {
		signin.click();
	}

	public void setemail(String emailval) {
		js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", emailValue);
		emailValue.sendKeys(emailval);
	}

	public void setPass(String password) {
		passwordValue.sendKeys(password);
	}

	public MyAccountPage submit() {
		submitLogin.click();
		return new MyAccountPage(driver);
	}

}
