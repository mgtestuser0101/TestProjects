package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import testcases.BaseTest;

public class SetAddressPage extends BaseTest {

	WebDriver driver;

	public SetAddressPage(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(xpath = "//*[@id='firstname']")
	WebElement firstName;

	@FindBy(xpath = "//*[@id='lastname']")
	WebElement lastName;

	@FindBy(xpath = "//*[@id='company']")
	WebElement company;

	@FindBy(xpath = "//*[@id='address1']")
	WebElement address1;

	@FindBy(xpath = "//*[@id='address2']")
	WebElement address2;

	@FindBy(xpath = "//*[@id='city']")
	WebElement city;

	@FindBy(xpath = "// *[@id='id_state']")
	WebElement state;

	@FindBy(xpath = "// *[@id='postcode']")
	WebElement postcode;

	@FindBy(xpath = "// *[@id='id_country']")
	WebElement country;

	@FindBy(xpath = "// *[@id='phone']")
	WebElement phone;

	@FindBy(xpath = "// *[@id='phone_mobile']")
	WebElement mobile;

	@FindBy(xpath = "// *[@id='other']")
	WebElement otherDetails;

	@FindBy(xpath = "// *[@id='alias']")
	WebElement addressAlias;

	@FindBy(xpath = "// *[contains(text(),'Save')]")
	WebElement saveAddress;

	public void setFirstName(String fname) {
		firstName.clear();
		firstName.sendKeys(fname);
	}

	public void setLastName(String lname) {
		lastName.clear();
		lastName.sendKeys(lname);
	}

	public void setCompany(String comp) {
		company.sendKeys(comp);
	}

	public void setAddress1(String add1) {
		address1.sendKeys(add1);
	}

	public void setAddress2(String add2) {
		address2.sendKeys(add2);
	}

	public void setCity(String town) {
		city.sendKeys(town);
	}

	public void state(String province) {
		Select select = new Select(state);
		select.selectByVisibleText(province);
	}

	public void setPost(String code) {
		postcode.sendKeys(code);
	}

	public void setCountry(String ctry) {
		Select select = new Select(country);
		select.selectByVisibleText(ctry);
	}

	public void setHomePhone(String phone1) {
		phone.sendKeys(phone1);
	}

	public void setMobilePhone(String phone2) {
		mobile.sendKeys(phone2);
	}

	public void setOthers(String others) {
		otherDetails.sendKeys(others);
	}

	public void alias(String alias) {
		addressAlias.clear();
		addressAlias.sendKeys(alias+System.currentTimeMillis());
	}

	public AddressDetailPage saveAddress() {
		saveAddress.click();
		return new AddressDetailPage(driver);
	}
}
