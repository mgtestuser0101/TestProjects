package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import testcases.BaseTest;

public class MyAddressesPage extends BaseTest {
	WebDriver driver;

	public MyAddressesPage(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(xpath = "//span[text()='Add a new address']")
	WebElement newAddress;

	public SetAddressPage addNewAddress() {

		Assert.assertEquals(driver.getTitle(), "Addresses - My Store");
		newAddress.click();
		return new SetAddressPage(driver);
	}

}
