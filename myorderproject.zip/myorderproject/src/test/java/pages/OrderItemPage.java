package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class OrderItemPage {

	WebDriver driver;
	JavascriptExecutor js;

	public OrderItemPage(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(xpath = "//*[@id='cart_title']")
	WebElement cartSummary;

	@FindBy(xpath = "//span[text()='Proceed to checkout']")
	WebElement proceedCheckOut;

	@FindBy(xpath = "//*[@id='address_delivery']")
	WebElement deliveryAddLabel;

	@FindBy(xpath = "//*[@id='address_invoice']")
	WebElement invoiceAddLabel;

	@FindBy(xpath = "//button[@type='submit' and @name='processAddress']/span[text()='Proceed to checkout']")
	WebElement proceedCheckOut2;

	@FindBy(xpath = "//span/input[@type='checkbox' and @id='cgv']")
	WebElement agreeTerms;

	@FindBy(xpath = "//button[@type='submit' and @name='processCarrier']/span[contains(text(),'Proceed to checkout')]")
	WebElement proceedCheckOut3;

	@FindBy(xpath = "//*[contains(text(),'Please choose your payment method')]")
	WebElement choosePayment;

	@FindBy(xpath = "//a[contains(text(),'Pay by bank wire')]")
	WebElement payByBankWire;

	@FindBy(xpath = "//*[contains(text(),'You have chosen to pay by bank wire. Here is a short summary of your order')]")
	WebElement bankWireSummary;

	@FindBy(xpath = "//span[contains(text(),'I confirm my order')]")
	WebElement confirmOrder;

	@FindBy(xpath = "//*[@class='page-heading' and text()='Order confirmation']")
	WebElement orderConfirmationTitle;

	@FindBy(xpath = "//*[@id='center_column']/div[@class='box']")
	WebElement orderInformation;

	@FindBy(xpath = "//a[@title='View my customer account']")
	WebElement viewMyProfile;

	public MyAccountPage buyItem() {
		Assert.assertEquals(driver.getTitle(), "Order - My Store");
		cartSummary.isDisplayed();
		proceedCheckOut.click();
		deliveryAddLabel.isDisplayed();
		invoiceAddLabel.isDisplayed();
		proceedCheckOut2.click();
		agreeTerms.click();
		proceedCheckOut3.click();
		choosePayment.isDisplayed();
		payByBankWire.click();
		bankWireSummary.isDisplayed();
		confirmOrder.click();
		Assert.assertEquals(driver.getTitle(), "Order confirmation - My Store");
		orderConfirmationTitle.isDisplayed();
		orderInformation.isDisplayed();
		js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", orderInformation);
		viewMyProfile.click();
		Assert.assertEquals(driver.getTitle(), "My account - My Store");
		return new MyAccountPage(driver);

	}

}
