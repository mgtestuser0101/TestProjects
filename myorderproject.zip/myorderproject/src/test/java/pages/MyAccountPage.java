package pages;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import testcases.BaseTest;

public class MyAccountPage extends BaseTest {

	WebDriver driver;
	JavascriptExecutor js;

	public MyAccountPage(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(xpath = "//a[@title='Addresses']")
	WebElement myAddress;

	@FindBy(xpath = "//span[contains(text(),'Order history and details')]")
	WebElement orderHistory;

	@FindBy(xpath = "//table[@id='order-list']")
	WebElement orderTable;
	
	@FindBy(xpath="//*[@id='center_column']")
	WebElement orderHistoryTable;
	
	@FindBy(xpath="//a[@title='Log me out']")
	WebElement signOut;

	public MyAddressesPage clickMyAddress() {
		Assert.assertEquals(driver.getTitle(), "My account - My Store");
		myAddress.click();
		return new MyAddressesPage(driver);
	}

	public void viewOrderHistory() {

		try {
			orderHistory.click();
			orderTable.isDisplayed();
			js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", orderHistoryTable);
			takeScreenshot();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
	
	public void logOut() {		
		signOut.click();
		Assert.assertEquals(driver.getTitle(), "Login - My Store");
	}

}
