package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import testcases.BaseTest;

public class AddressDetailPage extends BaseTest {

	WebDriver driver;

	public AddressDetailPage(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(xpath = "//*[text()='Your addresses are listed below.']")
	WebElement addressLabel;

	@FindBy(xpath = "//*[@id='block_top_menu']/ul/li[2]/a")
	WebElement dresses;

	public SelectDressPage clickDress() {
		Assert.assertEquals(driver.getTitle(), "Addresses - My Store");
		addressLabel.isDisplayed();
		dresses.click();
		Assert.assertEquals(driver.getTitle(), "Dresses - My Store");
		return new SelectDressPage(driver);

	}
}
