package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class SelectDressPage {

	WebDriver driver;
	JavascriptExecutor js;
	Actions act;

	public SelectDressPage(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(xpath = "//*[@id='categories_block_left']/descendant::a[contains(text(),'Casual Dresses')]")
	WebElement casualDress;

	@FindBy(xpath = "//a[contains(text(),'In stock')]")
	WebElement selectInStock;
	
	@FindBy(xpath="//ul[@class='product_list grid row']/li[1]/descendant::img")
	WebElement moveToImg;

	@FindBy(xpath = "//ul[@class='product_list grid row']/li[1]/descendant::a[@title='Add to cart']")
	WebElement addToCart;

	@FindBy(xpath = "//div[contains(@class,'layer_cart_product')]/h2")
	WebElement addCartConfirmation;

	@FindBy(xpath = "//a[@title='Proceed to checkout']")
	WebElement proceedCheckOut;

	@FindBy(xpath = "//span[@class='cross' and @title='Close window']")
	WebElement closeCart;

	@FindBy(xpath = "//*[@title='View my shopping cart']")
	WebElement goToCart;

	@FindBy(xpath = "//span[contains(text(),'Check out')]")
	WebElement checkOut;

	public OrderItemPage selectInStock() throws InterruptedException {
		Assert.assertEquals(driver.getTitle(), "Dresses - My Store");
		js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", selectInStock);
		selectInStock.click();
		act=new Actions(driver);
		act.moveToElement(moveToImg).click(addToCart).build().perform();		
		addCartConfirmation.isDisplayed();
		js.executeScript("arguments[0]. click();", proceedCheckOut);
		return new OrderItemPage(driver);
	}

}
