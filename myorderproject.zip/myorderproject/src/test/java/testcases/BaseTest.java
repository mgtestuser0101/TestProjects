package testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class BaseTest {

	public static WebDriver driver=null;
	public static Properties prop;

	public BaseTest() {

		try {
			prop = new Properties();
			FileInputStream fis;
			fis = new FileInputStream(
					System.getProperty("user.dir") + "/src/test/java/com/qa/mystore/resources/config.properties");
			try {
				prop.load(fis);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

	public void initialize() throws IOException {
		System.setProperty("webdriver.chrome.driver", "C:/Users/ADMIN/.eclipse/seleniumproj/driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(prop.getProperty("url"));
		Assert.assertEquals(driver.getTitle(), "My Store");
	}
	
	public void takeScreenshot() throws IOException {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String currentDir = System.getProperty("user.dir");
		FileUtils.copyFile(scrFile, new File(currentDir + "/screenshots/" +"MyStoreOrder_"+ System.currentTimeMillis() + ".png"));
	}

}
