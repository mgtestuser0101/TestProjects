package testcases;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.AddressDetailPage;
import pages.LoginPage;
import pages.MyAccountPage;
import pages.MyAddressesPage;
import pages.OrderItemPage;
import pages.SelectDressPage;
import pages.SetAddressPage;

public class TestCase extends BaseTest {

	LoginPage loginpage;
	MyAccountPage myaccpage;
	MyAddressesPage myaddresspage;
	SetAddressPage setAddressPage;
	AddressDetailPage addressDetailspage;
	SelectDressPage selectItem;
	OrderItemPage orderItem;

	public TestCase() {
		super();
	}

	@BeforeTest
	public void launchApp() throws IOException {
		initialize();
	}

	@Test(priority = 0)
	public void login() {

		loginpage = PageFactory.initElements(driver, LoginPage.class);
		loginpage.login();
		Assert.assertEquals(driver.getTitle(), "Login - My Store");
		loginpage.setemail(prop.getProperty("email"));
		loginpage.setPass(prop.getProperty("password"));
		loginpage.submit();
		Assert.assertEquals(driver.getTitle(), "My account - My Store");
	}

	@Test(priority = 1)
	public void myAccountAdress() {
		myaccpage = PageFactory.initElements(driver, MyAccountPage.class);
		myaccpage.clickMyAddress();
		Assert.assertEquals(driver.getTitle(), "Addresses - My Store");
	}

	@Test(priority = 2)
	public void clickAddress() {
		myaddresspage = PageFactory.initElements(driver, MyAddressesPage.class);
		myaddresspage.addNewAddress();
		Assert.assertEquals(driver.getTitle(), "Address - My Store");
	}

	@Test(priority = 3)
	public void enterAddress() {
		setAddressPage = PageFactory.initElements(driver, SetAddressPage.class);
		setAddressPage.setFirstName(prop.getProperty("name1"));
		setAddressPage.setLastName(prop.getProperty("name2"));
		setAddressPage.setCompany(prop.getProperty("comp"));
		setAddressPage.setAddress1(prop.getProperty("add1"));
		setAddressPage.setAddress2(prop.getProperty("add2"));
		setAddressPage.setCity(prop.getProperty("city"));
		setAddressPage.state(prop.getProperty("stat"));
		setAddressPage.setPost(prop.getProperty("zip"));
		setAddressPage.setCountry(prop.getProperty("cntry"));
		setAddressPage.setHomePhone(prop.getProperty("phone1"));
		setAddressPage.setMobilePhone(prop.getProperty("phone2"));
		setAddressPage.setOthers(prop.getProperty("other"));
		setAddressPage.alias(prop.getProperty("alias"));
		setAddressPage.saveAddress();
	}

	@Test(priority = 4)
	public void confirmAddress() {
		addressDetailspage = PageFactory.initElements(driver, AddressDetailPage.class);
		addressDetailspage.clickDress();
	}

	@Test(priority = 5)
	public void selectItem() throws InterruptedException {
		selectItem = PageFactory.initElements(driver, SelectDressPage.class);
		selectItem.selectInStock();
	}

	@Test(priority = 6)
	public void orderItem() {
		orderItem = PageFactory.initElements(driver, OrderItemPage.class);
		orderItem.buyItem();
	}

	@Test(priority = 7)
	public void orderHistory() {
		myaccpage = PageFactory.initElements(driver, MyAccountPage.class);
		myaccpage.viewOrderHistory();
	}

	@AfterTest
	public void exitApp() {
		myaccpage.logOut();
		driver.close();
		driver.quit();
	}
}
